package fr.goro.tutorial.spring.batch;

import org.springframework.boot.CommandLineRunner;

/**
 * Classe main de l'application.
 */
public class TutorialSpringBatchApplication {

    /**
     * Méthode principale minimaliste de l'application : point d'entrée.
     *
     * En l'état, l'application termine avec un code retour à zéro.
     *
     * @param args les arguments passé en paramétre de l'application.
     */
    public static void main(String[] args) {
        System.out.println("Hello world");
        System.exit(0);
    }
}